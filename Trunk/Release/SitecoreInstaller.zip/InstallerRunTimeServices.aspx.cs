﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SitecoreInstaller.Runtime
{
    public class InstallerRunTimeServices : System.Web.UI.Page
    {
        private readonly PackageService _packageService = new PackageService();
        private readonly ClientPostInstallService _clientPostInstallService = new ClientPostInstallService();

        protected void Page_Load(object sender, EventArgs e)
        {
            var invoke = HttpContext.Current.Request.QueryString["Invoke"];

            if (invoke == null)
                return;

            switch (invoke)
            {
                case "InstallAllPackages":
                    foreach (var package in _packageService.GetPackages())
                        _packageService.InstallPackage(package);
                    var response = _packageService.GetPackages().Aggregate("Installed packages", (current, installedPackage) => current + ("|" + installedPackage));
                    SetResponse(response);
                    break;
                case "ExecuteSecretPostInstallSteps":
                    _clientPostInstallService.SetCleanAdminWallpaper();
                    SetResponse("Secret Post Install Steps executed");
                    break;
            }
        }

        private void SetResponse(string message)
        {
            HttpContext.Current.Response.StatusCode = 200;
            HttpContext.Current.Response.StatusDescription = message;
            HttpContext.Current.Response.Flush();
            HttpContext.Current.Response.End();
        }
    }
}